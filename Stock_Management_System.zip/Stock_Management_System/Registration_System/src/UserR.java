import javax.swing.*;

public class UserR extends JFrame {
    public String U_ID;
    public String U_NAME;
    public String PASSWORD;
    public String EMAIL_ID;
    public String MOBILE_NO;
    public String ADDRESS;
}
